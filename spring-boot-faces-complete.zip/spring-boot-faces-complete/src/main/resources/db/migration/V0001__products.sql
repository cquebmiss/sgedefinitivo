create table product (
  id identity not null,
  name varchar (255) not null,
  price double not null
);
